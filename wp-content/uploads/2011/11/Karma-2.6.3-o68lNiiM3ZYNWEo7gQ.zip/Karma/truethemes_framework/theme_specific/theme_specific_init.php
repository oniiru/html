<?php
/*
* Loads theme specific file.
* @since version 2.6
*
*/

//site options
require_once(TEMPLATEPATH . '/truethemes_framework/theme_specific/karma_files/karma-site-option.php');

//admin functions
require_once(TEMPLATEPATH . '/truethemes_framework/theme_specific/karma_files/karma-admin-functions.php');

//unique theme functions for karma only
require_once(TEMPLATEPATH . '/truethemes_framework/theme_specific/karma_files/karma-functions.php');

//writes panel
require_once(TEMPLATEPATH . '/truethemes_framework/theme_specific/karma_files/karma-write-panels.php');

//Javascript Loader
require_once(TEMPLATEPATH . '/truethemes_framework/theme_specific/karma_files/karma-javascript.php');

//update notifier
require_once(TEMPLATEPATH . '/truethemes_framework/theme_specific/karma_files/karma-update-notifier.php');


?>