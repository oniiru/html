<?php 
/*
 * Creating Admin Video page
*/
 
class IonVideoPage {
	
	/**
	 * Page variables
	 */
	
	var $page_name = 'video-manager';
	var $edit_dir = 'edit-directory';
	var $delete_dir = 'delete-directory';
	var $delete_vid = 'delete-vid';
	
	/**
	 * Nonce variables
	 */
	
	var $add_video_directory_nonce = '44985';
	var $external_vid_nonce = '2222';
	var $video_list_nonce = '8888';
	var $added_video_list_nonce = '11111';
	
	function IonVideoPage() {		
		add_action('admin_menu', array(&$this, 'create_video_pages'));
		//add_action('admin_enqueue_scripts', array(&$this, 'register_scripts'));		
		add_action('admin_print_styles', array(&$this, 'register_styles') );
	}
	
	function create_video_pages() {
		$page = add_menu_page('Manage Video', 
					  'Video Manager', 
					  'administrator',
					  $this->page_name,
					  array(&$this,'index_page'),
					  '',
					  25
					  );
		
		add_submenu_page($this->page_name, 'Overview page', 'Overview', 'administrator', $this->page_name, array(&$this,'index_page'));
		
		add_action( 'admin_print_styles-' . $page, array(&$this, 'register_scripts') );
	}
	
	function index_page() {
		echo '<div class="wrap">';
		if( ($_GET['page'] == $this->page_name) && isset($_GET['pageAction'])) {
			switch($_GET['pageAction']) {
				case 'edit-directory' :
					if( isset($_GET['did']) && is_numeric($_GET['did']) ) :
						$this->edit_directory();
					else :
						$this->ion_overview_page();
					endif;
				break;
				case 'delete-directory' :
					if( isset($_GET['did']) && is_numeric($_GET['did']) ) :
						global $wpdb;
						$v_directory = get_option('v_directory_');
						
						if( $wpdb->get_var("SELECT COUNT(*) FROM $v_directory WHERE id = '".$_GET['did']."'") ) :
							if( $wpdb->query("DELETE FROM $v_directory WHERE id = '".$_GET['did']."'") ) {								
								$this->show_message('Video directory successfully deleted.');
							} else {
								$this->show_message('Execution failed. Please try again.' , 1);
							}
							
							$this->ion_overview_page();
						else : 
							$this->ion_overview_page();
						endif;
					endif;
				break;
				default :
					$this->ion_overview_page();
			}
		} else {
			$this->ion_overview_page();
		}
		echo '</div>';
	}

	function ion_overview_page() {
		$this->header_page('Overview/Add New Directory');
		$this->video_directory();
		echo '<br />';
		$this->add_new_directory();
		
	}
	
	function edit_directory() {
		global $wpdb;
		$filepath = admin_url() . 'admin.php?page=' . $this->page_name . '&pageAction=' . $this->edit_dir . '&did=' . $_GET['did'];
		$this->header_page('Add/Edit Video List');	
		$get_roles = $wpdb->prefix . 'user_roles';
		$all_roles = get_option($get_roles);
		
		# Chargify
		if( class_exists('ion_chargify') ) {
			$chargify = new ion_chargify();
			$products = $chargify->products();
		}
		//print_r('asdasd');
?>
		<div id="video-list-column">
		<div id="external-add-wrapper">
        	<form id="external-add_form" name="external-link-video" method="post" action="<?php echo $filepath; ?>">
            <?php wp_nonce_field($this->external_vid_nonce); ?>
            	<div id="external-add" class="postbox">
                	<h3 class="hndle"><span>External Add</span></h3>
                    <div class="inside">
                    	<p class="howto">You can an external link or an embed link.</p>
                        <label id="video-name-label" for="video-name" class="howto"><span>Label</span> <input id="video-name" class="howto" name="video[name]" type="text" /></label>
                        <br class="clear" />
                        <?php /* <label id="video-link-label" for="video-link" class="howto"><span>External Link</span> <input id="video-link" class="howto" name="video[link]" type="text" /></label>                       
                        <br class="clear" /> */?>
                        <label id="video-embed-label" for="video-embed" class="howto"><span>Embed</span> <textarea id="video-embed" class="howto" name="video[embed]" cols="" rows=""></textarea></label>
                        <br class="clear" />
                      <div id="video-duration-label" class="howto"><span>Duration</span> 
                        <br class="clear" />
                        <input name="video[duration][hours]" type="text" class="duration" id="video-duration-hour" value="000" maxlength="3" /> <span>:</span> <input name="video[duration][minutes]" type="text" class="duration" id="video-duration-minute"  value="00" maxlength="2"/> <span>:</span> <input name="video[duration][seconds]" type="text" class="duration" id="video-duration-seconds" value="00" maxlength="2" /> <span>(hours : minutes : seconds)</span></div>
                        <br class="clear" />
                        <?php if( $products ) : ?>
                        <h4 class="howto">Chargify Access Settings</h4>
                        <p>
                        <?php foreach( $products as $p ) { ?>
                        	<input id="chargify-option-ex-<?php echo $p->getHandle(); ?>" name="video[options][chargify][]" type="checkbox" value="<?php echo $p->getHandle(); ?>" /> <label for="chargify-option-ex-<?php echo $p->getHandle(); ?>"><?php echo $p->getName(); ?></label>
                        <?php } ?>
                        </p>
                        <?php endif; ?>
                        <h4 class="howto">Role</h4>
                        <p>
                        	<?php foreach ( $all_roles as $role_key => $role ) { ?>
                            <input id="role-option-ex-<?php echo $role_key; ?>" name="video[options][roles][]" type="checkbox" value="<?php echo $role_key; ?>" /> <label for="role-option-ex-<?php echo $role_key; ?>"><?php echo $role['name']; ?></label>                        
						<?php } ?>   
                        </p>
                         <p class="button-controls">
                            <span class="add-to-video-list">
                                <input type="submit" id="add-external-link" name="add-external-link" value="Add Video" class="button-secondary submit-add-to-menu">
                            </span>
                        </p>
                        <br class="clear" />
                    </div>
                </div>
            <input name="key" type="hidden" value="add_external_video_link" />
            <input name="did" type="hidden" value="<?php echo $_GET['did']; ?>" />
            </form><!-- #external-add_form -->
        </div><!-- #external-add-wrapper -->
        </div><!-- #video-list-column -->
        <div id="added-video-list-wrapper">
        	<form id="added-video-list_form" method="POST" action="<?php echo $filepath; ?>">
            <?php wp_nonce_field($this->added_video_list_nonce); ?>
            <?php
				$table = get_option('v_directory_');	
				$dir_name = $wpdb->get_var("SELECT directory_name FROM $table WHERE id ='".$_GET['did']."'");
			?>
        	<div id="added-video-header" class="ion-video-top-display">
            	<div class="video-submit-box">
                	<label for="directory-name" class="video-name-label howto open-label">
						<span>Video Directory</span>
                        <input type="text" value="<?php echo stripslashes( $dir_name ); ?>" title="Edit video directory name here" class="directory-name" id="directory-name" name="update-directory-name">
					</label>                   
					<div class="publishing-action">
						<input type="submit" value="Update" class="button-primary" id="update_added_videos" name="update_added_videos">												
                    </div>
                    <div class="clear"></div>
                </div><!-- .video-submit-box 1 -->
            </div><!-- #added-video-header -->            
        	<div id="added-video-list">
            <?php 
				global $wpdb;	
				
				$table = get_option('v_listings_');	
				$table2 = get_option('v_directory_');	
				
				$get_ = $wpdb->get_results( "SELECT video_order FROM $table2 WHERE id = '".$_GET['did']."'", ARRAY_A );
				$order = unserialize($get_[0]['video_order']);
			?>
            
            	<ul id="videos-to-edit">
               		<?php 
						if( is_array($order) ) :
				
						$i = 0;  foreach($order as $o) {
							$videos = $wpdb->get_results("SELECT * FROM $table WHERE ID IN (".$o.")", ARRAY_A);
							
							$video = $videos[0];
							$options = $video['options'];
							$options = unserialize($options);
							$options_ = $options[0];
					?>
					<li class="video-item">
                    	<dl class="video-item-bar">
                        	<dt class="video-item-handle"><span class="video-item"><?php echo stripslashes( $video['video_name'] ); ?></span><a href="#" title="Edit a Video Item" class="video-edit">Edit a Video Item</a><input type="hidden" name="order[]" value="<?php echo $video['ID']; ?>"/></dt>
                        </dl>
                        <div class="video-item-settings">
                        	<label id="added-video-name-label" for="added-video-name-<?php echo $i; ?>" class="video-name-label howto open-label">
                                <span>Video Name</span>
                                <input type="text" value="<?php echo stripslashes( $video['video_name'] ); ?>" class="directory-name howto" id="added-video-name-<?php echo $i; ?>" name="video[<?php echo $i; ?>][name]">
                            </label>
                            <label id="added-video-embed-label" for="added-embed-<?php echo $i; ?>" class="video-name-label howto open-label">
                                <span>Embed</span>
                                <textarea id="added-video-embed-<?php echo $i; ?>" class="directory-name howto" name="video[<?php echo $i; ?>][value]" cols="" rows=""><?php echo stripslashes(html_entity_decode( $video['embed_value'] )); ?></textarea>
                            </label>
                            <br class="clear" />
                            <div id="added-video-duration-label" class="howto"><span>Duration</span> 
							<br class="clear" />
                        <input name="video[<?php echo $i; ?>][duration][hours]" type="text" class="duration" id="added-video-duration-hour" value="<?php echo str_pad($options_['duration']['hours'], 3, 0, STR_PAD_LEFT); ?>" maxlength="3" /> <span>:</span> <input name="video[<?php echo $i; ?>][duration][minutes]" type="text" class="duration" id="added-video-duration-minute"  value="<?php echo str_pad($options_['duration']['minutes'], 2, 0, STR_PAD_LEFT); ?>" maxlength="2"/> <span>:</span> <input name="video[<?php echo $i; ?>][duration][seconds]" type="text" class="duration" id="added-duration-seconds" value="<?php echo str_pad($options_['duration']['seconds'], 2, 0, STR_PAD_LEFT); ?>" maxlength="2" /> <span>(hours : minutes : seconds)</span></div>
                         	<br class="clear" />
                            <?php if( $products ) :?>
							<h4 class="howto">Chargify Access Settings</h4>
                            <p>
                            <?php  $show_ = $options_; ?>
                            <?php foreach( $products as $p ) { ?>
                        	<input <?php if(!empty( $show_['options']['chargify'] ) && in_array( $p->getHandle(), $show_['options']['chargify'] )) : echo 'checked="checked"'; endif; ?> id="added-chargify-option-<?php echo $i . '-' . $p->getHandle(); ?>" name="video[<?php echo $i; ?>][options][chargify][]" type="checkbox" value="<?php echo $p->getHandle(); ?>" /> <label for="added-chargify-option-<?php echo $i . '-' . $p->getHandle(); ?>"><?php echo $p->getName(); ?></label>
                        <?php } ?>	
                            </p>
                            <?php endif; ?>
                        	<h4 class="howto">Role</h4>
                        	<?php foreach ( $all_roles as $role_key => $role ) { ?>
                            <input <?php if(!empty( $show_['options']['roles'] ) && in_array( $role_key, $show_['options']['roles'] )) : echo 'checked="checked"'; endif; ?> id="added-role-option-<?php echo $i . '-' . $role_key ?>" name="video[<?php echo $i; ?>][options][roles][]" type="checkbox" value="<?php echo $role_key; ?>" /> <label for="added-role-option-<?php echo $i . '-' . $role_key; ?>"><?php echo $role['name']; ?></label>                        
						<?php } ?>
                        <a href="#" class="video-item-delete video-submitdelete" title="<?php echo $video['ID']; ?>">Remove</a>      
                         <div class="clear"></div>                  
                        </div>
                    </li>
                    <?php $i++; } endif; ?>
                </ul>
			<?php  //endif; ?>
            </div><!-- #added-video-list -->
            <div id="added-video-footer" class="ion-video-bottom-display">
            	<div class="video-submit-box">  
                	<span id="update-msg" class="howto"></span>                
					<div class="publishing-action">
						<input type="submit" value="Update" class="button-primary" id="update_added_videos" name="update_added_videos">												
                    </div>
                    <div class="clear"></div>
                </div><!-- .video-submit-box 2 -->
            </div><!-- #added-video-footer -->
            <div id="for-deletion"></div>
            <input name="key" type="hidden" value="update_added_video_list" />
            <input name="did" type="hidden" value="<?php echo $_GET['did']; ?>" />
            </form>
        </div><!-- #added-video-list-wrapper -->
<?php
	}
	
	
	# Not used
	/*function overview() {
		echo '<div id="poststuff">';
		echo '<div id="video-directory" class="postbox">';
			echo '<h3 class="hndle">Sample 1</h3>';
			echo '<div class="video-directory-info inside">';
				echo 'sup';
			echo '</div>';
		echo '</div>';
		echo '</div>';
	}*/
	
	function header_page($page = '') {
?>		
		<div class="icon32" id="icon-themes"><br></div>
		<h2 class="nav-tab-wrapper">
		<a href="#" class="nav-tab"><?php echo $page ?></a>
		</h2>
<?php		
		// Submit function
		$this->process_submission();
	}
	
	function video_directory() {
		global $wpdb;
		$v_directory = get_option('v_directory_');		
		
		$get_lists = $wpdb->get_results("SELECT * FROM ".$v_directory." ORDER BY id ASC");		
?>
		<table id="video-directory" class="widefat">
		<thead>
			<tr>
		 		<th style="line-height:20px;" scope="col">Video Directory</th>
				<th style="line-height:20px;" scope="col">Video Count</th>
				<th style="line-height:20px;" scope="col">Date Crated</th>
				<th style="line-height:20px;" scope="col">Actions</th>
			</tr>
		</thead>
		<tbody>
        <?php foreach($get_lists as $list) { ?>
        	<tr>
            	<td><a href="<?php echo admin_url() . 'admin.php?page=' . $this->page_name . '&pageAction=' . $this->edit_dir . '&did=' . $list->id; ?>"><?php echo stripcslashes( $list->directory_name ); ?></a></td>
                <td><?php echo $list->video_count; ?></td>
                <td><?php echo date('m/d/y',strtotime($list->date_created)) ?></td>
                <td><a href="<?php echo admin_url() . 'admin.php?page=' . $this->page_name . '&pageAction=' . $this->edit_dir . '&did=' . $list->id; ?>">Edit</a> | <a onclick="return confirm('All videos hook to this directory will be deleted as well. Proceed?')" href="<?php echo admin_url() . 'admin.php?page=' . $this->page_name . '&pageAction=' . $this->delete_dir . '&did=' . $list->id; ?>">Delete</a></td>
            </tr>
        <?php } ?>		
		</tbody>		
		</table>
<?php
	}	
	
	function video_list() {
?>
		<div id="video-list-wrapper">        	
            <form id="video-list_form" action="<?php echo $filepath; ?>" method="post" name="video-list">
            <?php wp_nonce_field($this->video_list_nonce); ?>
            <div class="tablenav top">
                <div class="alignleft actions">
                    <select name="list_action">
                        <option value="-1">Bulk Actions</option>
                        <option value="add-selected">Add</option>
                        <option value="remove-selected">Remove</option>
                        <option value="delete-selected">Delete</option>
                    </select>
                <input type="submit" value="Apply" class="button-secondary action" id="doaction" name="doaction_list_video">
                </div>
            </div>
            <table id="video-list" class="widefat fixed">
            <thead>
                <tr>
                    <th class="check-column" scope="col"><input type="checkbox"></th>
                    <th style="line-height:20px;" scope="col" class="column-id">Video ID</th>
                    <th style="line-height:20px;" scope="col" class="column-title">Video Name</th>
                    <th style="line-height:20px;" scope="col" class="column-status">Status</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th class="check-column" scope="col"><input type="checkbox"></th>
                    <th style="line-height:20px;" scope="col" class="column-id">Video ID</th>
                    <th style="line-height:20px;" scope="col" class="column-title">Video Name</th>
                    <th style="line-height:20px;" scope="col" class="column-status">Status</th>
                </tr>
            </tfoot>
            <?php             
                # Get all videos
                $get_lists = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_type = 'attachment' AND post_mime_type  LIKE 'video%' ORDER BY ID ASC");			
            ?>
            <tbody> 
            <?php foreach($get_lists as $list) { ?>
                <tr>
                    <th class="check-column" scope="row"><input type="checkbox" name="list[]" value="<?php echo $list->ID; ?>"></th>
                    <td class="column-id"><?php echo $list->ID ?>
                    </td>
                    <td class="column-title">
                    	<a href="<?php echo admin_url(). 'media.php?attachment_id='. $list->ID . '&action=edit'; ?>"><?php echo $list->post_title; ?></a>
                    <div class="row-actions">
                    	<span class="edit"><a href="<?php echo admin_url(). 'media.php?attachment_id='. $list->ID . '&action=edit'; ?>" title="Edit the video">Edit</a> | </span><span class="inline hide-if-no-js"><a title="Show options" name="<?php echo $list->ID ?>" class="video_options_btn" href="#">Show Options</a></span>
                        </div>
                    </td>                    
                    <td class="column-status">Not Added</td>
                   
                </tr>                
                <tr id="show-option-<?php echo $list->ID; ?>" class="inline-edit-row hidden">
                	<td></td>
                    <td></td>
                	<td id="video-options-<?php echo $list->ID; ?>" class="colspanchange column-title">
                    <h4>Role</h4>
                    	<?php foreach ( $all_roles as $role_key => $role ) { ?>
                            <input id="role-option-<?php echo $list->ID . '-' . $role_key ?>" name="video[<?php echo $list->ID; ?>][options][roles][]" type="checkbox" value="<?php echo $role_key; ?>" /> <label for="role-option-<?php echo $list->ID . '-' . $role_key; ?>"><?php echo $role['name']; ?></label>                        
						<?php } ?>
                    </td>
                    <td></td>
                </tr>             
            <?php } ?>    
            </tbody>
            </table>
            <div class="tablenav top">
                <div class="alignleft actions">
                    <select name="list_action-2">
                        <option value="-1">Bulk Actions</option>
                        <option value="add-selected">Add</option>
                        <option value="remove-selected">Remove</option>
                        <option value="delete-selected">Delete</option>
                    </select>
                <input type="submit" value="Apply" class="button-secondary action" id="doaction" name="doaction_list_video">
                </div>
            </div>
            <input name="key" type="hidden" value="update_video_list" />
            </form><!-- #video-list_form -->
		</div><!-- #video-list-wrapper -->
<?php
	}
	
	function add_new_directory() {
		$filepath = admin_url().'admin.php?page='.$this->page_name;
?>
		<h2>Add New Video Directory</h2>
        <br />
		<form id="video-directory_form" name="video-directory" method="post" accept-charset="utf-8" action="<?php echo $filepath; ?>">
        <?php wp_nonce_field($this->add_video_directory_nonce); ?>
		<table>
		<tbody>
			<tr valign="top">
				<td  style="width:20%;"><input type="text" size="40" name="name_of_directory"></td>
				<td><input type="submit" value="Add directory" id="add_newdir_btn" name="add_dir" class="button-primary"></td>
			</tr>
		</tbody>		
		</table>
        <i>( Allowed characters for file and folder names are: a-z, A-Z, 0-9, -, _ )</i>
        <input name="key" type="hidden" value="new_directory" />
        </form>
<?php
	}
	
	function process_submission() {	
		
		if(!empty($_POST) && isset($_POST['key'])) {
			switch($_POST['key']) {
				
				/**
				 * Process submitted form to an a new directory
				 * 
				 * @since 1.0.0
				 */
				
				case 'new_directory':				
					if( check_admin_referer($this->add_video_directory_nonce) ) :
						global $wpdb;
						
						# Old Method
						
						/*
						$table = get_option('v_directory');							
						$this->authenticate_($_POST['name_of_directory'], array( $table, 'directory_name' ) );
						*/
						
						# End
						
						$table_ = get_option('v_directory_');
						$var = $_POST['name_of_directory'];
						
						if( $wpdb->get_var("SELECT COUNT(*) FROM $table_ WHERE 'directory_name' = '$var'") ) :
							return $this->show_message("An <b>ERROR</b> has occured: Directory '<b>".$var."</b>' already exist.",1);
						else :
							if($wpdb->insert( $table_, array(
														'directory_name' => $var, 
														'video_count' => 0, 
														'date_created' => date('Y-m-d'),
														'video_order' => ''
														) )) 
							{
								$this->show_message('New Directory Added');
							}
							
						endif;
						
					endif;
					
				break;
				case 'update_video_list' :
					if( check_admin_referer($this->video_list_nonce) ) :	
						echo '<pre>';
							print_r($_POST);
						echo '</pre>';						
						if( ($_POST['list_action'] != -1) && ($_POST['list_action'] != -1) ) {
							switch($_POST['list_action']) {
								case 'add-selected' :
									//echo 'sup?';
									/*foreach($_POST['list'] as $id) {
										// Get Roles
										echo $_POST['video_option'][$id]['roles'] . '<br />';
									}*/
								break;
							}								
						} else {
								$this->show_message('No action taken.');
						}
					endif;
				break;
				
				/**
				 * Process and add submitted form for external links
				 *
				 * Upon submission it will verify the nonce and input fields, if no error, proceed creating the array values, else, return fail.
				 * Verifies if dir_id has already exist and has existing value, if that is the case it will prepend the submitted value to an
				 * existing mysql value. If not, do an insert query.
				 *
				 * @since 1.0.0
				 * @uses $wpdb
				 * @return text To verify that the query is successful or it has failed.
				 */
				
				case 'add_external_video_link' :
					if( check_admin_referer($this->external_vid_nonce) ) :
						global $wpdb;
						
						$stack = array();
						$stack_ = array();
						if( empty($_POST['video']['name']) ) {
							return $this->show_message('An <b>ERROR</b> has occured: Label should not be empty.',1);
						}
						
						if(empty( $_POST['video']['embed'] )) {
							return $this->show_message('An <b>ERROR</b> has occured: External embed should not be empty.',1);
						}
						
						if(empty( $_POST['video']['duration']['hours'] ) || empty( $_POST['video']['duration']['minutes'] ) || empty( $_POST['video']['duration']['seconds'] )) {
							return $this->show_message('An <b>ERROR</b> has occured: Duration should not be empty.',1);
						} elseif(!ctype_digit( $_POST['video']['duration']['hours'] ) || !ctype_digit( $_POST['video']['duration']['minutes'] ) || !ctype_digit( $_POST['video']['duration']['seconds'] )) {
							return $this->show_message('An <b>ERROR</b> has occured: Duration should be an integer.',1);
						}
						
						// New version
						array_push($stack_ ,array('duration' => $_POST['video']['duration'], 'options' => $_POST['video']['options']));
						// End
						
						// New version
						$table_ = get_option('v_listings_');
						$table2_ = get_option('v_directory_');
						// End
						
						// New version
						
						$stack_ = serialize($stack_);
						$vid_counter_ = count($stack_);
							
							
							if( $wpdb->insert( $table_, array( 'dir_id' => $_POST['did'], 'video_name' => $_POST['video']['name'], 'embed_value' => esc_textarea( $_POST['video']['embed'] ), 'options' => $stack_) ) ) {
								
								$the_id = $wpdb->insert_id;		
								
								$old_order = $wpdb->get_results("SELECT video_order FROM $table2_ WHERE id = '".$_POST['did']."'", ARRAY_A);	
								$old_order = unserialize($old_order[0]['video_order']);
								
								if(is_array($old_order)) :
									$old_order[] =  $the_id;
									$new_order = $old_order;
									
									$order = serialize($new_order);
								else :
									$new_order = array();
									$new_order[] =  $the_id;
								endif;
								
								$order = serialize($new_order);								
								
								$vid_counter_ = count($new_order);
								
									if( $wpdb->update( $table2_, array('video_count' => $vid_counter_, 'video_order' => $order), array('id' => $_POST['did']) )) {	
										$this->show_message('Video added to the directory');
									} else {
										echo $wpdb->last_query;
										$this->show_message('An error has occured. Please try again.', 1);
										
									}
								
							} else {
								$this->show_message('An error has occured. Please try again.', 1);
							}
					endif; # check_admin_referer
				break;
				case 'update_added_video_list' :
					if( check_admin_referer($this->added_video_list_nonce) ) :
						global $wpdb;
						$stack = array();	
						$vid_counter = 0;
						if( empty($_POST['update-directory-name']) ) {
								return $this->show_message('Update failed: Directory name should not be empty.',1);
						}				
							
						$dir_name = $_POST['update-directory-name'];
						
						if(!empty( $_POST['video'] )) {
							$value = $_POST['video'];
							
						$order = $_POST['order'];
						
						$table1_ = get_option('v_listings_');
						$table2_ = get_option('v_directory_');
						
						if( $wpdb->get_var("SELECT COUNT(*) FROM $table2_ WHERE directory_name = '$dir_name' AND id != '". $_POST['did'] ."'") ) :
							return $this->show_message("An <b>ERROR</b> has occured: Directory '<b>".$dir_name."</b>' already exist.",1);
						else :							
								
							$vid_counter_ = 0;
							foreach($value as $val) {								
								if(empty( $val['name'] ) || empty( $val['value'] ) || empty( $val['duration']['hours'] ) || empty( $val['duration']['minutes'] ) || empty( $val['duration']['seconds'] ) ) {
									return $this->show_message('Update failed: One of the added video must not have an empty field (except for the view options).',1);									
								} elseif (!ctype_digit( $val['duration']['hours'] ) || !ctype_digit( $val['duration']['minutes'] ) || !ctype_digit( $val['duration']['seconds'] )) {
									return $this->show_message('Update failed: Duration should be an integer.',1);
								}
							}
							
							foreach($value as $val) {
								$stack_ = array();
								array_unshift($stack_, array('duration' => $val['duration'], 'options' => $val['options']));
								$stack_ = serialize($stack_);
								
								$wpdb->update( $table1_, array('video_name' => $val['name'], 'embed_value' => esc_textarea( $val['value'] ), 'options' => $stack_), array( 'ID' => $order[0] ) );
								
								array_shift( $order );
								
								$vid_counter_++;
							}
							
							$new_order = $_POST['order'];
							$new_order = serialize($new_order);
							$wpdb->update($table2_, array( 'directory_name' => $dir_name, 'video_count' => $vid_counter_, 'video_order' => $new_order ), array('id' => $_POST['did']));
							
							if(is_array( $_POST['for_deletion'] )) { 
								foreach($_POST['for_deletion'] as $delete) {
									$wpdb->query("DELETE FROM $table1_ WHERE ID = '$delete'");
								}								
							}
							
							$this->show_message('Video added to the directory');
						endif;
						}						
					endif;
				break;
			}
		}
	}
	
	function show_message( $msg, $type = 0) {
		if(!empty($msg)) :
			switch($type) {
				case 0:
				case 'message':
					echo '<div class="updated fade"><p>' . $msg . '</p></div>' . "\n";
					break;
				case 1:
				case 'error':
					echo '<div class="error fade"><p>' . $msg . '</p></div>' . "\n";
					break;
			}
		else :
			return;
		endif;
	}
	
	function authenticate_($variable, $data = array()) {
		global $wpdb;
		
		if( preg_match( '/[\'^�$%&*()}{@#~?><>,|=+�]/', $variable ) ) { // Check for Special Characters
			 return $this->show_message('An <b>ERROR</b> has occured: Special characters are not allowed.',1);
		}
		
		if(is_array($data) && !empty($data)) {
			if( $wpdb->get_var("SELECT COUNT(*) FROM $data[0] WHERE $data[1] = '$variable'") ) :
				return $this->show_message("An <b>ERROR</b> has occured: Directory '<b>".$variable."</b>' already exist.",1);
			else :
				if($wpdb->insert( $data[0], array(
											'directory_name' => $variable, 
											'video_count' => 0, 
											'date_created' => date('Y-m-d') 
											) )) 
				{
					$this->show_message('New Directory Added');
				}
			endif;
				
		}
	}
	
	function register_scripts() {
		wp_register_script( 'ion-admin','/wp-content/plugins/ion/admin/js/ion-admin.js', array('jquery'),'1.0.0');		
		wp_enqueue_script( 'ion-admin' );
		wp_enqueue_script( 'jquery-ui-sortable' );
		
	}
	
	function register_styles() {
		wp_enqueue_style( 'ion-admin-css', '/wp-content/plugins/ion/admin/css/ion-admin.css', false, '1.0.0', 'screen' );
		wp_enqueue_style( 'ion-admin-css' );
	}
}

$ion_vedeopage = &new IonVideoPage();

?>