<?php
/**
 * Load all scripts and stylesheet for the WP front-end
 * @since 1.0.0
 */

function video_directory_style() {
		wp_enqueue_style( 'video-directory-style', '/wp-content/plugins/ion/css/video-directory.css', false, '1.0.0', 'screen' );
		wp_enqueue_style( 'video-directory-style' );
		
		wp_enqueue_style( 'ui-custom', '/wp-content/plugins/ion/css/ui-dialog.css', false, '1.0.0', 'screen' );
		wp_enqueue_style( 'ui-custom' );
}

function video_directory_scripts() {
		wp_register_script( 'video-directory-scripts', '/wp-content/plugins/ion/js/video-directory.js', array('jquery'), '1.0.0');
		wp_enqueue_script( 'video-directory-scripts' );
		wp_enqueue_script( 'jquery-ui-dialog' );
		wp_enqueue_script( 'jquery-ui-resizable' );
		wp_enqueue_script( 'jquery-ui-tabs' );
}

function facybox() {
		wp_register_script( 'facybox-mousewheel', '/wp-content/plugins/ion/display/fancybox/jquery.mousewheel-3.0.4.pack.js', array('jquery'), '1.0.0' );
		wp_enqueue_script( 'facybox-mousewheel' );
		wp_register_script( 'facybox-js', '/wp-content/plugins/ion/display/fancybox/jquery.fancybox-1.3.4.pack.js', array('jquery'), '1.0.0' );
		wp_enqueue_script( 'facybox-js' );
		
		wp_enqueue_style( 'fancybox-stylesheet', '/wp-content/plugins/ion/display/fancybox/jquery.fancybox-1.3.4.css', false, '1.0.0', 'screen' );
		wp_enqueue_style( 'fancybox-stylesheet' );
}

add_action('init', 'facybox' );
add_action('init', 'video_directory_style' );
add_action('init', 'video_directory_scripts' );

?>