<?php
/*
* Loads theme specific file according to activated theme.
* Loads specific files from karma_files, sterling_files, etc..
* @since version 2.6
*
*/


//Loads Karma or Karma Child Theme specific file

$theme_name = get_current_theme();

if($theme_name == "Karma" || $theme_name == "Karma Child Theme"){

//site options
require_once(TEMPLATEPATH . '/truethemes_framework/theme_specific/karma_files/karma-site-option.php');

//admin functions
require_once(TEMPLATEPATH . '/truethemes_framework/theme_specific/karma_files/karma-admin-functions.php');

//unique theme functions for karma only
require_once(TEMPLATEPATH . '/truethemes_framework/theme_specific/karma_files/karma-functions.php');

//writes panel
require_once(TEMPLATEPATH . '/truethemes_framework/theme_specific/karma_files/karma-write-panels.php');

//Javascript Loader
require_once(TEMPLATEPATH . '/truethemes_framework/theme_specific/karma_files/karma-javascript.php');

//update notifier
require_once(TEMPLATEPATH . '/truethemes_framework/theme_specific/karma_files/karma-update-notifier.php');

}

?>