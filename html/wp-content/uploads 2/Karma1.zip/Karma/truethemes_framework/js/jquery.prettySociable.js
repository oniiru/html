/* ------------------------------------------------------------------------
 * prettySociable plugin.
 * Version: 1.2.1
 * Description: Include this plugin in your webpage and let people
 * share your content like never before.
 * Website: http://no-margin-for-errors.com/projects/prettySociable/
 * 						
 * Thank You: 
 * Chris Wallace, for the nice icons
 * http://www.chris-wallace.com/2009/05/28/free-social-media-icons-socialize/
 * ------------------------------------------------------------------------- */
 
 var TTjquery = jQuery.noConflict();

(function(TTjquery){TTjquery.prettySociable={version:1.21};TTjquery.prettySociable=function(settings){TTjquery.prettySociable.settings=jQuery.extend({animationSpeed:'fast',opacity:0.80,share_label:'Drag to share',label_position:'top',share_on_label:'Share on ',hideflash:false,hover_padding:0,websites:{facebook:{'active':true,'encode':true,'title':'Facebook','url':'http://www.facebook.com/share.php?u=','icon':'https://s3.amazonaws.com/Karma-WP/facebook.png','sizes':{'width':70,'height':70}},twitter:{'active':true,'encode':true,'title':'Twitter','url':'http://twitter.com/home?status=','icon':'https://s3.amazonaws.com/Karma-WP/twitter.png','sizes':{'width':70,'height':70}},delicious:{'active':true,'encode':true,'title':'Delicious','url':'http://del.icio.us/post?url=','icon':'https://s3.amazonaws.com/Karma-WP/delicious.png','sizes':{'width':70,'height':70}},digg:{'active':true,'encode':true,'title':'Digg','url':'http://digg.com/submit?phase=2&url=','icon':'https://s3.amazonaws.com/Karma-WP/digg.png','sizes':{'width':70,'height':70}},linkedin:{'active':false,'encode':true,'title':'LinkedIn','url':'http://www.linkedin.com/shareArticle?mini=true&ro=true&url=','icon':'http://','sizes':{'width':70,'height':70}},reddit:{'active':false,'encode':true,'title':'Reddit','url':'http://reddit.com/submit?url=','icon':'http://files.truethemes.net/themes/karma-wp/reddit.png','sizes':{'width':70,'height':70}},stumbleupon:{'active':false,'encode':false,'title':'StumbleUpon','url':'http://stumbleupon.com/submit?url=','icon':'http://','sizes':{'width':70,'height':70}},tumblr:{'active':false,'encode':true,'title':'tumblr','url':'http://www.tumblr.com/share?v=3&u=','icon':'http://','sizes':{'width':70,'height':70}}},urlshortener:{bitly:{'active':false}},tooltip:{offsetTop:0,offsetLeft:15},popup:{width:900,height:500},callback:function(){}},settings);var websites,settings=TTjquery.prettySociable.settings,show_timer,ps_hover;TTjquery.each(settings.websites,function(i){var preload=new Image();preload.src=this.icon;});TTjquery('a[rel^=prettySociable]').hover(function(){_self=this;_container=this;if(TTjquery(_self).find('img').size()>0){_self=TTjquery(_self).find('img');}else if(TTjquery.browser.msie){if(TTjquery(_self).find('embed').size()>0){_self=TTjquery(_self).find('embed');TTjquery(_self).css({'display':'block'});}}else{if(TTjquery(_self).find('object').size()>0){_self=TTjquery(_self).find('object');TTjquery(_self).css({'display':'block'});}}
TTjquery(_self).css({'cursor':'move','position':'relative','z-index':1005});offsetLeft=(parseFloat(TTjquery(_self).css('borderLeftWidth')))?parseFloat(TTjquery(_self).css('borderLeftWidth')):0;offsetTop=(parseFloat(TTjquery(_self).css('borderTopWidth')))?parseFloat(TTjquery(_self).css('borderTopWidth')):0;offsetLeft+=(parseFloat(TTjquery(_self).css('paddingLeft')))?parseFloat(TTjquery(_self).css('paddingLeft')):0;offsetTop+=(parseFloat(TTjquery(_self).css('paddingTop')))?parseFloat(TTjquery(_self).css('paddingTop')):0;ps_hover=TTjquery('<div id="ps_hover"> \
        <div class="ps_hd"> \
         <div class="ps_c"></div> \
        </div> \
        <div class="ps_bd"> \
         <div class="ps_c"> \
          <div class="ps_s"> \
          </div> \
         </div> \
        </div> \
        <div class="ps_ft"> \
         <div class="ps_c"></div> \
        </div> \
        <div id="ps_title"> \
         <div class="ps_tt_l"> \
          '+settings.share_label+' \
         </div> \
        </div> \
       </div>').css({'width':TTjquery(_self).width()+(settings.hover_padding+8)*2,'top':TTjquery(_self).position().top-settings.hover_padding-8+parseFloat(TTjquery(_self).css('marginTop'))+offsetTop,'left':TTjquery(_self).position().left-settings.hover_padding-8+parseFloat(TTjquery(_self).css('marginLeft'))+offsetLeft}).hide().insertAfter(_container).fadeIn(settings.animationSpeed);TTjquery('#ps_title').animate({top:-15},settings.animationSpeed);TTjquery(ps_hover).find('>.ps_bd .ps_s').height(TTjquery(_self).height()+settings.hover_padding*2);fixCrappyBrowser('ps_hover',this);DragHandler.attach(TTjquery(this)[0]);TTjquery(this)[0].dragBegin=function(e){_self=this;show_timer=window.setTimeout(function(){TTjquery('object,embed').css('visibility','hidden');TTjquery(_self).animate({'opacity':0},settings.animationSpeed);TTjquery(ps_hover).remove();overlay.show();tooltip.show(_self);tooltip.follow(e.mouseX,e.mouseY);sharing.show();},200);};TTjquery(this)[0].drag=function(e){tooltip.follow(e.mouseX,e.mouseY);}
TTjquery(this)[0].dragEnd=function(element,x,y){TTjquery('object,embed').css('visibility','visible');TTjquery(this).attr('style',0);overlay.hide();tooltip.checkCollision(element.mouseX,element.mouseY);};},function(){TTjquery(ps_hover).fadeOut(settings.animationSpeed,function(){TTjquery(this).remove()});}).click(function(){clearTimeout(show_timer);});var tooltip={show:function(caller){tooltip.link_to_share=(TTjquery(caller).attr('href')!="#")?TTjquery(caller).attr('href'):location.href;if(settings.urlshortener.bitly.active){if(window.BitlyCB){BitlyCB.myShortenCallback=function(data){var result;for(var r in data.results){result=data.results[r];result['longUrl']=r;break;};tooltip.link_to_share=result['shortUrl'];};BitlyClient.shorten(tooltip.link_to_share,'BitlyCB.myShortenCallback');};};attributes=TTjquery(caller).attr('rel').split(';');for(var i=1;i<attributes.length;i++){attributes[i]=attributes[i].split(':');};desc=(TTjquery('meta[name=Description]').attr('content'))?TTjquery('meta[name=Description]').attr('content'):"";if(attributes.length==1){attributes[1]=['title',document.title];attributes[2]=['excerpt',desc];}
ps_tooltip=TTjquery('<div id="ps_tooltip"> \
         <div class="ps_hd"> \
          <div class="ps_c"></div> \
         </div> \
         <div class="ps_bd"> \
          <div class="ps_c"> \
           <div class="ps_s"> \
           </div> \
          </div> \
         </div> \
         <div class="ps_ft"> \
          <div class="ps_c"></div> \
         </div> \
            </div>').appendTo('body');TTjquery(ps_tooltip).find('.ps_s').html("<p><strong>"+attributes[1][1]+"</strong><br />"+attributes[2][1]+"</p>");fixCrappyBrowser('ps_tooltip');},checkCollision:function(x,y){collision="";scrollPos=_getScroll();TTjquery.each(websites,function(i){if((x+scrollPos.scrollLeft>TTjquery(this).offset().left&&x+scrollPos.scrollLeft<TTjquery(this).offset().left+TTjquery(this).width())&&(y+scrollPos.scrollTop>TTjquery(this).offset().top&&y+scrollPos.scrollTop<TTjquery(this).offset().top+TTjquery(this).height())){collision=TTjquery(this).find('a');}});if(collision!=""){TTjquery(collision).click();}
sharing.hide();TTjquery('#ps_tooltip').remove();},follow:function(x,y){scrollPos=_getScroll();settings.tooltip.offsetTop=(settings.tooltip.offsetTop)?settings.tooltip.offsetTop:0;settings.tooltip.offsetLeft=(settings.tooltip.offsetLeft)?settings.tooltip.offsetLeft:0;TTjquery('#ps_tooltip').css({'top':y+settings.tooltip.offsetTop+scrollPos.scrollTop,'left':x+settings.tooltip.offsetLeft+scrollPos.scrollLeft});}}
var sharing={show:function(){websites_container=TTjquery('<ul />');TTjquery.each(settings.websites,function(i){var _self=this;if(_self.active){link=TTjquery('<a />').attr({'href':'#'}).html('<img src="'+_self.icon+'" alt="'+_self.title+'" width="'+_self.sizes.width+'" height="'+_self.sizes.height+'" />').hover(function(){sharing.showTitle(_self.title,TTjquery(this).width(),TTjquery(this).position().left,TTjquery(this).height(),TTjquery(this).position().top);},function(){sharing.hideTitle();}).click(function(){shareURL=(_self.encode)?encodeURIComponent(tooltip.link_to_share):tooltip.link_to_share;popup=window.open(_self.url+shareURL,"prettySociable","location=0,status=0,scrollbars=1,width="+settings.popup.width+",height="+settings.popup.height);});TTjquery('<li>').append(link).appendTo(websites_container);};});TTjquery('<div id="ps_websites"><p class="ps_label"></p></div>').append(websites_container).appendTo('body');fixCrappyBrowser('ps_websites');scrollPos=_getScroll();TTjquery('#ps_websites').css({'top':TTjquery(window).height()/2-TTjquery('#ps_websites').height()/2+scrollPos.scrollTop,'left':TTjquery(window).width()/2-TTjquery('#ps_websites').width()/2+scrollPos.scrollLeft});websites=TTjquery.makeArray(TTjquery('#ps_websites li'));},hide:function(){TTjquery('#ps_websites').fadeOut(settings.animationSpeed,function(){TTjquery(this).remove()});},showTitle:function(title,width,left,height,top){TTjquerylabel=TTjquery('#ps_websites .ps_label');TTjquerylabel.text(settings.share_on_label+title)
TTjquerylabel.css({'left':left-TTjquerylabel.width()/2+width/2,'opacity':0,'display':'block'}).stop().animate({'opacity':1,'top':top-height+45},settings.animationSpeed);},hideTitle:function(){TTjquery('#ps_websites .ps_label').stop().animate({'opacity':0,'top':10},settings.animationSpeed);}};var overlay={show:function(){TTjquery('<div id="ps_overlay" />').css('opacity',0).appendTo('body').height(TTjquery(document).height()).fadeTo(settings.animationSpeed,settings.opacity);},hide:function(){TTjquery('#ps_overlay').fadeOut(settings.animationSpeed,function(){TTjquery(this).remove();});}}
var DragHandler={_oElem:null,attach:function(oElem){oElem.onmousedown=DragHandler._dragBegin;oElem.dragBegin=new Function();oElem.drag=new Function();oElem.dragEnd=new Function();return oElem;},_dragBegin:function(e){var oElem=DragHandler._oElem=this;if(isNaN(parseInt(oElem.style.left))){oElem.style.left='0px';}
if(isNaN(parseInt(oElem.style.top))){oElem.style.top='0px';}
var x=parseInt(oElem.style.left);var y=parseInt(oElem.style.top);e=e?e:window.event;oElem.mouseX=e.clientX;oElem.mouseY=e.clientY;oElem.dragBegin(oElem,x,y);document.onmousemove=DragHandler._drag;document.onmouseup=DragHandler._dragEnd;return false;},_drag:function(e){var oElem=DragHandler._oElem;var x=parseInt(oElem.style.left);var y=parseInt(oElem.style.top);e=e?e:window.event;oElem.style.left=x+(e.clientX-oElem.mouseX)+'px';oElem.style.top=y+(e.clientY-oElem.mouseY)+'px';oElem.mouseX=e.clientX;oElem.mouseY=e.clientY;oElem.drag(oElem,x,y);return false;},_dragEnd:function(){var oElem=DragHandler._oElem;var x=parseInt(oElem.style.left);var y=parseInt(oElem.style.top);oElem.dragEnd(oElem,x,y);document.onmousemove=null;document.onmouseup=null;DragHandler._oElem=null;}};function _getScroll(){if(self.pageYOffset){scrollTop=self.pageYOffset;scrollLeft=self.pageXOffset;}else if(document.documentElement&&document.documentElement.scrollTop){scrollTop=document.documentElement.scrollTop;scrollLeft=document.documentElement.scrollLeft;}else if(document.body){scrollTop=document.body.scrollTop;scrollLeft=document.body.scrollLeft;}
return{scrollTop:scrollTop,scrollLeft:scrollLeft};};function fixCrappyBrowser(element,caller){if(TTjquery.browser.msie&&TTjquery.browser.version==6){if(typeof DD_belatedPNG!='undefined'){if(element=='ps_websites'){TTjquery('#'+element+' img').each(function(){DD_belatedPNG.fixPng(TTjquery(this)[0]);});}else{DD_belatedPNG.fixPng(TTjquery('#'+element+' .ps_hd .ps_c')[0]);DD_belatedPNG.fixPng(TTjquery('#'+element+' .ps_hd')[0]);DD_belatedPNG.fixPng(TTjquery('#'+element+' .ps_bd .ps_c')[0]);DD_belatedPNG.fixPng(TTjquery('#'+element+' .ps_bd')[0]);DD_belatedPNG.fixPng(TTjquery('#'+element+' .ps_ft .ps_c')[0]);DD_belatedPNG.fixPng(TTjquery('#'+element+' .ps_ft')[0]);}};};}};})(jQuery);


//prettySocialble init script
var TTjquery = jQuery.noConflict();
TTjquery(document).ready(function () {
			TTjquery.prettySociable();
			TTjquery.prettySociable.settings.urlshortener.bitly.active = true;
});