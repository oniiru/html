<?php
/*
* Required TrueThemes Framework
* Moved all define constant to folder in truethemes_framework_init.php
* @since version 2.6 development
*/
require_once(TEMPLATEPATH . '/truethemes_framework/truethemes_framework_init.php');



/********You can add your codes below****************/

/*
* Note to users:
* Please kindly use the child theme and add your codes in the child theme's functions.php
* So as to prevent lost of your codes after theme upgrade.
*/








/********Do not add below this line****************/
?>