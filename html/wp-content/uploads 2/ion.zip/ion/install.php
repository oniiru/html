<?php 

class DB_install {
	var $dbversion   = '1.0.0';
	
	function DB_install() {
		register_activation_hook(__FILE__, array(&$this, 'activate_db') );
	}
	
	function activate_db() {
		
		if (version_compare(PHP_VERSION, '5.2.0', '<')) { 
				deactivate_plugins(plugin_basename(__FILE__)); // Deactivate ourself
                wp_die("Sorry, but you can't run this plugin, it requires PHP 5.2 or higher."); 
				return; 
        } 
		
		$this->install_tables();
	}
	
	function install_tables() {
		global $wpdb;
		
		// upgrade function changed in WordPress 2.3	
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		
		$v_directory = $wpdb->prefix . "video_name_directoryasdsad";
		$v_listings = $wpdb->prefix . "video_listings";	
		
		if( !$wpdb->get_var( "SHOW TABLES LIKE '$v_directory'" ) ) { // Veriry if table exist
			$sql = "CREATE TABLE ".$v_directory." (
					id INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
					directory_name VARCHAR( 1000 ) NOT NULL ,
					video_count INT NOT NULL ,
					date_created DATETIME DEFAULT '0000-00-00 00:00:00' NOT NULL
					)";
			dbDelta($sql);	
		}	
		
		if( !$wpdb->get_var( "SHOW TABLES LIKE '$v_listings'" ) ) { // Veriry if table exist
			$sql = "CREATE TABLE ".$v_listings." (
					dir_id INT NOT NULL ,
					vid_id INT NOT NULL ,
					options LONGTEXT NOT NULL ,
					order_by INT DEFAULT '0' NOT NULL
					)";
			dbDelta($sql);	
		}
		
		if( $wpdb->get_var( "SHOW TABLES LIKE '$v_directory'" ) && $wpdb->get_var( "SHOW TABLES LIKE '$v_listings'" ) ) {
			add_option("ion_dbversion", $this->dbversion);
		}
	}
}


$db_install = &new DB_install();

?>