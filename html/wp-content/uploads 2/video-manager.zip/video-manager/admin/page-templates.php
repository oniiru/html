<?php 

class IonVideoPageTemplates {
	function added_videos() {
		global $wpdb;
		$get_roles = $wpdb->prefix . 'user_roles';
		$all_roles = get_option($get_roles);
		
		# Chargify
		if( class_exists('ion_chargify') ) {
			$chargify = new ion_chargify();
			$products = $chargify->products();
		}
?>
	<div id="added-video-list-wrapper">
        	<form id="added-video-list_form" method="POST" action="<?php echo $filepath; ?>">
            <?php wp_nonce_field($this->added_video_list_nonce); ?>
            <?php
				$table = get_option('v_directory_');	
				$dir_name = $wpdb->get_var("SELECT directory_name FROM $table WHERE id ='".$_GET['did']."'");
			?>
        	<div id="added-video-header" class="ion-video-top-display">
            	<div class="video-submit-box">
                	<label for="directory-name" class="video-name-label howto open-label">
						<span>Video Directory</span>
                        <input type="text" value="<?php echo stripslashes( $dir_name ); ?>" title="Edit video directory name here" class="directory-name" id="directory-name" name="update-directory-name">
					</label>                   
					<div class="publishing-action">
						<input type="submit" value="Update" class="button-primary" id="update_added_videos" name="update_added_videos">												
                    </div>
                    <div class="clear"></div>
                </div><!-- .video-submit-box 1 -->
            </div><!-- #added-video-header -->            
        	<div id="added-video-list">
            <?php 
				
				$table = get_option('v_listings_');	
				$table2 = get_option('v_directory_');	

				$get_ = $wpdb->get_results( "SELECT video_order FROM $table2 WHERE id = '".$_GET['did']."'", ARRAY_A );
				$order = unserialize($get_[0]['video_order']);
			?>
            
            	<ul id="videos-to-edit">
               		<?php 
						if( is_array($order) ) :
				
						$i = 0;  foreach($order as $o) {
							$videos = $wpdb->get_results("SELECT * FROM $table WHERE ID IN (".$o.")", ARRAY_A);
							
							$video = $videos[0];
							$options = $video['options'];
							$options = unserialize($options);
							$options_ = $options[0];
					?>
					<li class="video-item">
                    	<dl class="video-item-bar">
                        	<dt class="video-item-handle"><span class="video-item"><?php echo stripslashes( $video['video_name'] ); ?></span><a href="#" title="Edit a Video Item" class="video-edit">Edit a Video Item</a><input type="hidden" name="order[]" value="<?php echo $video['ID']; ?>"/></dt>
                        </dl>
                        <div class="video-item-settings">
                        	<label id="added-video-name-label" for="added-video-name-<?php echo $i; ?>" class="video-name-label howto open-label">
                                <span>Video Name</span>
                                <input type="text" value="<?php echo stripslashes( $video['video_name'] ); ?>" class="directory-name howto" id="added-video-name-<?php echo $i; ?>" name="video[<?php echo $i; ?>][name]">
                            </label>                       
                            <?php if( empty( $options_['media_id'] ) ) : ?>
                            <label id="added-video-embed-label" for="added-embed-<?php echo $i; ?>" class="video-name-label howto open-label">
                                <span>Embed</span>
                                <textarea id="added-video-embed-<?php echo $i; ?>" class="directory-name howto" name="video[<?php echo $i; ?>][value]" cols="" rows=""><?php echo stripslashes(html_entity_decode( $video['embed_value'] )); ?></textarea>
                            </label>
                            <input name="video[<?php echo $i; ?>][width]" type="hidden" value="300" />
                            <input name="video[<?php echo $i; ?>][height]" type="hidden" value="200" />
                            <?php else : ?>
                             <div class="media-attachment">
                            	 <span>Media Attachment ID:</span> <b><a href="<?php echo admin_url(). 'media.php?attachment_id='. $options_['media_id'] . '&action=edit'; ?>"><?php echo $options_['media_id']; ?></a></b>
                                 <input name="video[<?php echo $i; ?>][media_id]" type="hidden" value="<?php echo $options_['media_id']; ?>" />
                             </div>
                             <br class="clear" />
                             <div id="video-width-height-label" class="howto">
                                <input name="video[<?php echo $i; ?>][width]" class="video-resize" type="text" id="video-width" value="<?php echo $options_['width']; ?>" maxlength="3" />
                                <span>x</span>                         
                                <input name="video[<?php echo $i; ?>][height]"  class="video-resize" type="text" id="video-height" value="<?php echo $options_['height']; ?>" maxlength="3" />
                                <span>Width x Height</span>
                            </div>
                            <?php endif; ?>
                            <br class="clear" />                            
                            <div id="added-video-duration-label" class="howto"><span>Duration</span> 
							<br class="clear" />
                        <input name="video[<?php echo $i; ?>][duration][hours]" type="text" class="duration" id="added-video-duration-hour" value="<?php echo str_pad($options_['duration']['hours'], 3, 0, STR_PAD_LEFT); ?>" maxlength="3" /> <span>:</span> <input name="video[<?php echo $i; ?>][duration][minutes]" type="text" class="duration" id="added-video-duration-minute"  value="<?php echo str_pad($options_['duration']['minutes'], 2, 0, STR_PAD_LEFT); ?>" maxlength="2"/> <span>:</span> <input name="video[<?php echo $i; ?>][duration][seconds]" type="text" class="duration" id="added-duration-seconds" value="<?php echo str_pad($options_['duration']['seconds'], 2, 0, STR_PAD_LEFT); ?>" maxlength="2" /> <span>(hours : minutes : seconds)</span></div>
                         	<br class="clear" />
                            <?php if( $products ) :?>
							<h4 class="howto">Chargify Access Settings</h4>
                            <p>
                            <?php  $show_ = $options_; ?>
                            <?php foreach( $products as $p ) { ?>
                        	<input <?php if(!empty( $show_['options']['chargify'] ) && in_array( $p->getHandle(), $show_['options']['chargify'] )) : echo 'checked="checked"'; endif; ?> id="added-chargify-option-<?php echo $i . '-' . $p->getHandle(); ?>" name="video[<?php echo $i; ?>][options][chargify][]" type="checkbox" value="<?php echo $p->getHandle(); ?>" /> <label for="added-chargify-option-<?php echo $i . '-' . $p->getHandle(); ?>"><?php echo $p->getName(); ?></label>
                        <?php } ?>	
                            </p>
                            <?php endif; ?>
                        	<h4 class="howto">Role</h4>
                        	<?php foreach ( $all_roles as $role_key => $role ) { ?>
                            <input <?php if(!empty( $show_['options']['roles'] ) && in_array( $role_key, $show_['options']['roles'] )) : echo 'checked="checked"'; endif; ?> id="added-role-option-<?php echo $i . '-' . $role_key ?>" name="video[<?php echo $i; ?>][options][roles][]" type="checkbox" value="<?php echo $role_key; ?>" /> <label for="added-role-option-<?php echo $i . '-' . $role_key; ?>"><?php echo $role['name']; ?></label>                        
						<?php } ?>
                        <a href="#" class="video-item-delete video-submitdelete" title="<?php echo $video['ID']; ?>">Remove</a>      
                         <div class="clear"></div>                  
                        </div>
                    </li>
                    <?php $i++; } endif; ?>
                </ul>
			<?php  //endif; ?>
            </div><!-- #added-video-list -->
            <div id="added-video-footer" class="ion-video-bottom-display">
            	<div class="video-submit-box">  
                	<span id="update-msg" class="howto"></span>                
					<div class="publishing-action">
						<input type="submit" value="Update" class="button-primary" id="update_added_videos" name="update_added_videos">												
                    </div>
                    <div class="clear"></div>
                </div><!-- .video-submit-box 2 -->
            </div><!-- #added-video-footer -->
            <div id="for-deletion"></div>
            <input name="key" type="hidden" value="update_added_video_list" />
            <input name="did" type="hidden" value="<?php echo $_GET['did']; ?>" />
            </form>
        </div><!-- #added-video-list-wrapper -->
<?php
	}
	
	function external_add() {
		global $wpdb;
		$get_roles = $wpdb->prefix . 'user_roles';
		$all_roles = get_option($get_roles);
		
		# Chargify
		if( class_exists('ion_chargify') ) {
			$chargify = new ion_chargify();
			$products = $chargify->products();
		}
?>
	<div id="external-add-wrapper">
        	<form id="external-add_form" name="external-link-video" method="post" action="<?php echo $filepath; ?>">
            <?php wp_nonce_field($this->external_vid_nonce); ?>
            	<div id="external-add" class="postbox">
                	<h3 class="hndle"><span>External Add</span></h3>
                    <div class="inside">
                    	<p class="howto">You can an external link or an embed link.</p>
                        <label id="video-name-label" for="video-name" class="howto"><span>Label</span> <input id="video-name" class="howto" name="video[name]" type="text" /></label>
                        <br class="clear" />
                        <label id="video-embed-label" for="video-embed" class="howto"><span>Embed</span> <textarea id="video-embed" class="howto" name="video[embed]" cols="" rows=""></textarea></label>
                        <br class="clear" />
                      <div id="video-duration-label" class="howto"><span>Duration</span> 
                        <br class="clear" />
                        <input name="video[duration][hours]" type="text" class="duration" id="video-duration-hour" value="000" maxlength="3" /> <span>:</span> <input name="video[duration][minutes]" type="text" class="duration" id="video-duration-minute"  value="00" maxlength="2"/> <span>:</span> <input name="video[duration][seconds]" type="text" class="duration" id="video-duration-seconds" value="00" maxlength="2" /> <span>(hours : minutes : seconds)</span></div>
                        <br class="clear" />
                        <?php if( $products ) : ?>
                        <h4 class="howto">Chargify Access Settings</h4>
                        <p>
                        <?php foreach( $products as $p ) { ?>
                        	<input id="chargify-option-ex-<?php echo $p->getHandle(); ?>" name="video[options][chargify][]" type="checkbox" value="<?php echo $p->getHandle(); ?>" /> <label for="chargify-option-ex-<?php echo $p->getHandle(); ?>"><?php echo $p->getName(); ?></label>
                        <?php } ?>
                        </p>
                        <?php endif; ?>
                        <h4 class="howto">Role</h4>
                        <p>
                        	<?php foreach ( $all_roles as $role_key => $role ) { ?>
                            <input id="role-option-ex-<?php echo $role_key; ?>" name="video[options][roles][]" type="checkbox" value="<?php echo $role_key; ?>" /> <label for="role-option-ex-<?php echo $role_key; ?>"><?php echo $role['name']; ?></label>                        
						<?php } ?>   
                        </p>
                         <p class="button-controls">
                            <span class="add-to-video-list">
                                <input type="submit" id="add-external-link" name="add-external-link" value="Add Video" class="button-secondary submit-add-to-menu">
                            </span>
                        </p>
                        <br class="clear" />
                    </div>
                </div>
            <input name="key" type="hidden" value="add_external_video_link" />
            <input name="did" type="hidden" value="<?php echo $_GET['did']; ?>" />
            </form><!-- #external-add_form -->
        </div><!-- #external-add-wrapper -->
<?php
	}
}

?>