// JavaScript Document

jQuery(document).ready( function() {
    jQuery('.postbox h3').click( function() {
        jQuery(jQuery(this).parent().get(0)).toggleClass('closed');
    });
	
	jQuery('.video_options_btn').click( function() {
		var id = jQuery(this).attr('name');
		//alert(id);
		jQuery(jQuery('#show-option-'+id).toggleClass('hidden'));
		return false;
	});
	
	jQuery( "#videos-to-edit" ).sortable({
			placeholder: "ion-sortable-placeholder"
	});
	
	jQuery('.video-edit').click( function() {
		jQuery(jQuery(this).closest('li').get(0)).toggleClass('open-sesame');
		return false;
	});
	
	jQuery('.video-item-delete').click( function() {
		var id = jQuery(this).attr('title');
		
		jQuery(jQuery(this).closest('li').get(0)).remove();
		jQuery('#for-deletion').prepend('<input name="for_deletion[]" type="hidden" value="'+id+'" />');
		jQuery('#update-msg').html('Click <strong>Update</strong> for changes to take effect.');
		
		return false;
	});
});