<?php
/**
 * Load all scripts and stylesheet for the WP front-end
 * @since 1.0.0
 */

function video_directory_style() {
		wp_enqueue_style( 'video-directory-style', $GLOBALS['url_path'] . '/css/video-directory.css', false, '1.0.0', 'screen' );
		wp_enqueue_style( 'video-directory-style' );
		
		wp_enqueue_style( 'ui-custom', $GLOBALS['url_path'] . '/css/ui-dialog.css', false, '1.0.0', 'screen' );
		wp_enqueue_style( 'ui-custom' );
}

function video_directory_scripts() {
		wp_register_script( 'video-directory-scripts', $GLOBALS['url_path'] . '/js/video-directory.js', array('jquery'), '1.0.0');
		wp_enqueue_script( 'video-directory-scripts' );
		wp_enqueue_script( 'jquery-ui-dialog' );
		wp_enqueue_script( 'jquery-ui-resizable' );
		wp_enqueue_script( 'jquery-ui-tabs' );
}

function facybox() {
		wp_register_script( 'facybox-mousewheel', $GLOBALS['url_path'] . '/display/fancybox/jquery.mousewheel-3.0.4.pack.js', array('jquery'), '1.0.0' );
		wp_enqueue_script( 'facybox-mousewheel' );
		wp_register_script( 'facybox-js', $GLOBALS['url_path'] . '/display/fancybox/jquery.fancybox-1.3.4.pack.js', array('jquery'), '1.0.0' );
		wp_enqueue_script( 'facybox-js' );
		
		wp_enqueue_style( 'fancybox-stylesheet', $GLOBALS['url_path'] . '/display/fancybox/jquery.fancybox-1.3.4.css', false, '1.0.0', 'screen' );
		wp_enqueue_style( 'fancybox-stylesheet' );
}

function jw_player() {
	wp_register_script( 'jw-player', $GLOBALS['url_path'] . '/display/mediaplayer-5.8/jwplayer.js' );
	wp_enqueue_script( 'jw-player' );
}

if( !is_admin() ) {
	add_action('wp_enqueue_scripts', 'facybox');
	add_action('wp_enqueue_scripts', 'jw_player');
	add_action('init', 'video_directory_style');
	add_action('wp_enqueue_scripts', 'video_directory_scripts');
}

?>