jQuery(function(){
    jQuery("#et_anticipate_date").datetimepicker();
});